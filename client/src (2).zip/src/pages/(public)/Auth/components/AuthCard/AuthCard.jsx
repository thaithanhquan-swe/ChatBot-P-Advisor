import { NavLink } from 'react-router-dom';

const tabs = [
  { label: 'Đăng nhập', to: '/login' },
  { label: 'Đăng ký', to: '/register' },
];

const AuthCard = ({ children }) => {
  return (
    <div className='w-full overflow-hidden rounded-(--radius-panel) border border-(--border-subtle) bg-white shadow-(--shadow-card-hover)'>
      <div className='grid grid-cols-2'>
        {tabs.map((tab) => (
          <NavLink
            key={tab.to}
            to={tab.to}
            className={({ isActive }) =>
              `border-b-2 py-4 text-center text-[14.5px] font-semibold transition-colors ${
                isActive
                  ? 'border-(--primary-color) text-(--primary-color)'
                  : 'border-(--border-subtle) text-(--text-secondary) hover:text-gray-700'
              }`
            }
          >
            {tab.label}
          </NavLink>
        ))}
      </div>

      <div className='p-8 sm:p-10'>{children}</div>
    </div>
  );
};

export default AuthCard;
