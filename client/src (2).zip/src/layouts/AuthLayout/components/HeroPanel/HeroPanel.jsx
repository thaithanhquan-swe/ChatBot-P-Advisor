import { Link } from 'react-router-dom';
import { Clock, FileText, MessageCircleMore, ShieldCheck } from 'lucide-react';

import { images } from '@/assets/images';

const features = [
  {
    icon: MessageCircleMore,
    title: 'Tư vấn thông minh',
    desc: 'Chatbot AI hiểu rõ thông tin tuyển sinh của PTIT',
  },
  {
    icon: FileText,
    title: 'Thông tin đầy đủ',
    desc: 'Cung cấp toàn bộ thông tin tuyển sinh mới nhất',
  },
  {
    icon: Clock,
    title: 'Hỗ trợ 24/7',
    desc: 'Luôn sẵn sàng giải đáp mọi thắc mắc của bạn',
  },
  {
    icon: ShieldCheck,
    title: 'Bảo mật thông tin',
    desc: 'Cam kết bảo mật tuyệt đối thông tin cá nhân',
  },
];

const HeroPanel = () => {
  return (
    <div className='relative hidden overflow-hidden bg-(--surface-muted) lg:flex lg:w-[46%] lg:shrink-0 lg:flex-col lg:justify-center lg:px-16 xl:px-20'>
      {/* Decorative blobs */}
      <div className='pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-(--primary-color-soft) blur-3xl' />
      <div className='pointer-events-none absolute -right-16 -bottom-28 h-80 w-80 rounded-full bg-(--primary-color-soft) blur-3xl' />

      {/* Decorative building illustration */}
      <img
        src={images.truong_ptit}
        alt=''
        aria-hidden='true'
        className='pointer-events-none absolute inset-x-0 bottom-0 w-full grayscale opacity-[0.06]'
      />

      <div className='relative z-10'>
        <Link to='/' className='inline-flex'>
          <img src={images.logo_ptit} alt='PTIT' className='h-14 w-auto object-contain' />
        </Link>

        <h1 className='mt-8 text-[26px] leading-snug font-bold text-gray-900 xl:text-[30px]'>
          Chào mừng bạn đến với
          <br />
          <span className='text-(--primary-color)'>PTIT Admission Chatbot</span>
        </h1>

        <p className='mt-4 max-w-105 text-[14.5px] leading-relaxed text-(--text-secondary)'>
          Trợ lý tư vấn tuyển sinh thông minh của Học viện Công nghệ Bưu chính Viễn thông
        </p>

        <div className='mt-10 space-y-6'>
          {features.map(({ icon: Icon, title, desc }) => (
            <div key={title} className='flex items-start gap-3.5'>
              <div className='flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white shadow-(--shadow-card)'>
                <Icon size={20} className='text-(--primary-color)' strokeWidth={1.8} />
              </div>
              <div>
                <h3 className='text-[14.5px] font-semibold text-gray-900'>{title}</h3>
                <p className='mt-1 text-[13px] leading-relaxed text-(--text-secondary)'>{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroPanel;
