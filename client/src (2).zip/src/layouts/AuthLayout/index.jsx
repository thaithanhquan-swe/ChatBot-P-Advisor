import { Outlet } from 'react-router-dom';

import HeroPanel from '@/layouts/AuthLayout/components/HeroPanel/HeroPanel';

function AuthLayout() {
  return (
    <div className='flex min-h-screen w-full bg-white'>
      <HeroPanel />

      <main className='flex flex-1 items-center justify-center px-4 py-10 sm:px-8'>
        <div className='w-full max-w-115'>
          <Outlet />
        </div>
      </main>
    </div>
  );
}

export default AuthLayout;
